const express = require('express');
const nodemailer = require('nodemailer');

const app = express();
const port = 3000;

// Create a transporter object using the default SMTP transport
const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    auth: {
        user: 'se32001project@gmail.com',
        pass: 'aqwu vpiw fhel ggox'
    }
});

// Endpoint to send test email
app.get('/send-test-email', (req, res) => {
    // Define email options
    const mailOptions = {
        from: 'se32001project@gmail.com',
        to: '7147150349@vtext.com', // Replace with your email address
        subject: '',
        text: 'This is a test email sent from Node.js.'
    };

    // Send email
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error occurred:', error);
            res.status(500).send('Error occurred while sending test email.');
        } else {
            console.log('Test email sent successfully!');
            console.log('Message ID:', info.messageId);
            console.log('Preview URL:', nodemailer.getTestMessageUrl(info));
            res.status(200).send('Test email sent successfully.');
        }
    });
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
