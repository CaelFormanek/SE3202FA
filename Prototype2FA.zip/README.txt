
Prototype Two-Factor Authentication System Readme

Description - 
This is a prototype two-factor authentication (2FA) system built using Node.js and Express, 
along with HTML, CSS, and JavaScript for the frontend. The system sends a verification code 
via text or email and prompts the user to enter the code for authentication. We plan on moving 
away from text or email to make it device based. 

Components - 
Server-side (Node.js and Express)
Express: A web application framework for Node.js used to create server routes and handle HTTP requests.
Nodemailer: A module for Node.js applications to send emails.
Client-side (HTML, CSS, JavaScript)

HTML: The markup language used to structure the web page.
CSS: Stylesheet language used for styling the HTML elements.
JavaScript: Used to implement client-side functionality such as sending requests to the server and handling user interactions.

Setup Instructions:
- Install Dependencies: Run npm install in the project directory to install the required Node.js packages.
- Configure Gmail SMTP: Replace the Gmail SMTP credentials (user and pass) in the Node.js server code (server.js) 
  with your own Gmail email and password.
- Run the Server: Start the Node.js server by running node server.js or npm start in the terminal. The server 
  will start listening on port 3000 by default.

Access the Application: Open a web browser and navigate to http://localhost:3000 to access the login page.

Usage Instructions
Login: Enter the username and password. If the credentials are correct, a verification code will be generated and sent to the provided email address.
Verify Code: Enter the verification code received in the email. If the entered code matches the generated code, the user will be successfully logged in.

Files Included
server.js: Node.js server code implementing the Express routes and Nodemailer functionality.
Website.html: HTML file containing the login form and client-side JavaScript code for handling user interactions.
WebsiteStyles.css: CSS file for styling the HTML elements.

Additional Notes
This is a prototype implementation and should not be used in production without further security 
considerations and testing. The Gmail SMTP configuration may require allowing less secure apps 
to access your Gmail account. Use caution and consider using a dedicated email service for sending 
authentication emails in production environments. For additional security, consider implementing 
more robust authentication mechanisms and incorporating libraries like Passport.js for user 
authentication.

Author
[Connor] - [2395380]