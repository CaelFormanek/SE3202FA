const express = require('express');
const nodemailer = require('nodemailer');

const app = express();
const port = 3000;

// Create a transporter object using the default SMTP transport
const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    auth: {
        user: 'se32001project@gmail.com',
        pass: 'fttq aawo nghn merr'
    }
});

function generateVerificationCode() {
    return Math.floor(10000 + Math.random() * 90000); // Generates a random number between 10000 and 99999
}

// Store verification codes in an object
const verificationCodes = {};

// Endpoint to send test email and open a new window
app.get('/send-test-email', (req, res) => {
    // Generate a 5-digit verification code
    const verificationCode = generateVerificationCode();

    // Store the verification code
    const email = '7147150349@vtext.com'; // Replace with your email address
    verificationCodes[email] = verificationCode;

    // Define email options
    const mailOptions = {
        from: 'se32001project@gmail.com',
        to: email,
        subject: 'Verification Code',
        text: `Your 5-digit verification code is: ${verificationCode}`
    };

    // Send email
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error occurred:', error);
            res.status(500).send('Error occurred while sending test email.');
        } else {
            console.log('Test email sent successfully!');
            console.log('Message ID:', info.messageId);
            console.log('Verification Code:', verificationCode);
            // Render the verification code entry page
            res.send(`
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Verification Code</title>
                </head>
                <body>
                    <h2>Enter Verification Code</h2>
                    <form action="/verify-code" method="GET">
                        <div>
                            <label for="code">Verification Code:</label>
                            <input type="text" id="code" name="code" required>
                            <input type="hidden" name="email" value="${email}">
                        </div>
                        <button type="submit">Submit</button>
                    </form>
                </body>
                </html>
            `);
        }
    });
});

// Endpoint to verify the verification code
app.get('/verify-code', (req, res) => {
    const { email, code } = req.query;

    // Check if the verification code matches
    if (verificationCodes[email] && verificationCodes[email] == code) {
        res.send('Verification successful!');
    } else {
        res.send('Verification failed. Incorrect code or code expired.');
    }
});


// // Endpoint to send test email
// app.get('/send-test-email', (req, res) => {
//     // Define email options
//     const mailOptions = {
//         from: 'se32001project@gmail.com',
//         to: '7147150349@vtext.com', // Replace with your email address
//         subject: '',
//         text: 'This is a test email sent from Node.js.'
//     };

//     // Send email
//     transporter.sendMail(mailOptions, (error, info) => {
//         if (error) {
//             console.error('Error occurred:', error);
//             res.status(500).send('Error occurred while sending test email.');
//         } else {
//             console.log('Test email sent successfully!');
//             console.log('Message ID:', info.messageId);
//             console.log('Preview URL:', nodemailer.getTestMessageUrl(info));
//             res.status(200).send('Test email sent successfully.');
//         }
//     });
// });

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
